<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dosen extends CI_Controller {
    public function index()
	{
        $this->load->model("dosen_model","dsn1");
        $this->dsn1->nidn='2022001';
        $this->dsn1->nama='Sirojul Munir, S.Si, M.Kom';
        $this->dsn1->pendidikan='S2 Ilmu Komputer';
        $this->dsn1->gender='L';

        $this->load->model("dosen_model","dsn2");
        $this->dsn2->nidn='2022002';
        $this->dsn2->nama='Yahya Zulkarnain, S.T.';
        $this->dsn2->pendidikan='S1 Teknik Informatika';
        $this->dsn2->gender='L';

        $this->load->model("dosen_model","dsn3");
        $this->dsn3->nidn='2022003';
        $this->dsn3->nama='Pudy Prima, S.T., M.Kom';
        $this->dsn3->pendidikan='S2 Ilmu Komputer';
        $this->dsn3->gender='P';

        $list_dsn = [$this->dsn1, $this->dsn2, $this->dsn3];
        $data['list_dsn']=$list_dsn;
        $this->load->view('header');
		$this->load->view('dosen/index',$data);
        $this->load->view('footer');
	}
}
