<h1 style="text-align: center;">Daftar Dosen</h1>
<br>
<br>
<table border="1" width="100%">
    <thead style="background-color: rgb(205, 240, 188);">
        <tr>
            <th>No</th>
            <th>NIDN</th>
            <th>Nama Dosen</th>
            <th>Pendidikan</th>
            <th>Gender</th>
        </tr>
    </thead>
    <tbody>
    <?php
    $nomor = 1;
    foreach($list_dsn as $obj){
        ?>
        <tr>
            <td><?=$nomor?></td>
            <td><?=$obj->nidn?></td>
            <td><?=$obj->nama?></td>
            <td><?=$obj->pendidikan?></td>
            <td><?=$obj->gender?></td>
        </tr>
    <?php
    $nomor++;
    }?>  
    </tbody>
</table>