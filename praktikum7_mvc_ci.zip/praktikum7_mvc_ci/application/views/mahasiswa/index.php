<h1 style="text-align: center;">Daftar Mahasiswa</h1>
<br>
<br>
<table border="1" width="100%">
    <thead style="background-color: rgb(205, 240, 188);">
        <tr>
            <th>No</th>
            <th>NIM</th>
            <th>Nama Mahasiswa</th>
            <th>Gender</th>
            <th>IPK</th>
            <th>Predikat</th>
        </tr>
    </thead>
    <tbody>
    <?php
    $nomor = 1;
    foreach($list_mhs as $obj){
        ?>
        <tr>
            <td><?=$nomor?></td>
            <td><?=$obj->nim?></td>
            <td><?=$obj->nama?></td>
            <td><?=$obj->gender?></td>
            <td><?=$obj->ipk?></td>
            <td><?=$obj->predikat()?></td>
        </tr>
        <?php
        $nomor++;
    }?>
    </tbody>
</table>