<h1 style="text-align: center;">Daftar Matakuliah</h1>
<br>
<br>
<table border="1" width="100%">
    <thead style="background-color: rgb(205, 240, 188);">
        <tr>
            <th>No</th>
            <th>Kode</th>
            <th>Nama Matakuliah</th>
            <th>Jumlah SKS</th>
        </tr>
    </thead>
    <tbody>
    <?php
    $nomor = 1;
    foreach($list_matkul as $obj){
        ?>
        <tr>
            <td><?=$nomor?></td>
            <td><?=$obj->kode?></td>
            <td><?=$obj->nama?></td>
            <td><?=$obj->sks?></td>
    <?php
    $nomor++;
    }?>
    </tbody>
</table>
